
<!DOCTYPE html>
<html>
<head>
<meta  charset="UTF-8">
     <title>MAMA RESTAURANT</title>
     <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">  
<link rel="stylesheet" href="reserv.css">

</head>

  <body>
  <h1 class="head">RESERVATION</h1>
       <div class="container">
        <div class="container-time">
           <h2 class ="heading">Time Open</h2>
           <h3 class = "heading-day">Monday-Friday</h3>
           <p>9am - 11pm (Breakfast)</p>
            <p>11am - 9pm (Lunch/Dinner)</p>
            
            <h3 class="heading-day">Saturday and Sunday </h3>
            <p>9am - 1am (Breakfast)</p>
            <p>11am - 10pm (Lunch/Dinner)</p>
            
            <hr>
            <h4 class="heading-phone">Call Us:(+358)455-547-75</h4>
           </div>
           <div class="container-form">
          
                <h2 class ="heading-two">Reservation</h2>

	<form method="post" action="proces.php">
	<div class="form-field">
		<p>Your Name:</p>
		<input type="text" name="first_name" class="arpit" Required>
		<br>
		</div>
		<div class="form-field">
		<p>Your email:</p>
		<input type="text" name="last_name"class="arpit">
		<br>
		</div>
		<div class="form-field">
		<p>Date:</p>
        <input type="date" name="city_name" class="form-control arpit" Required>
		<br>
		</div>
		<div class="form-field">
		<p>Time:</p>
		<input type="time" name="email" class="arpit">
		<br>
		</div>
		<div class="form-field">
		<p>Number of Members:</p>
		<input type="text" name="member" class="arpit" Required>
		<br>

		</div>
		<input type="submit" name="save" class="btn" value="submit">
		<button class="btn btn-success"><a href="update1.php">Check Reservation</a></button>
	</form>
	</div>
  </body>
</html>