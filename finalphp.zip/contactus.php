<?php include 'header.php' ?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/contact.css">
  </head> 
 <body>
 
 <div class="text">
    <center><h1>Have Any Question?</h1></center>
     <hr>
    <center><h2>"We'd Love to Hear From You."</h2></center>
    
</div>
 
<form method="post" action="user_process.php">
  
<div class="cont-form">
    
    <div class="tx-box">
      <label>Full Name :</label>
      <input type="text" name="fullname" value="" placeholder="Enter Name..">
    </div>

    <div class="tx-box">
      <label>Email :</label>
      <input type="text" name="email"  value="" placeholder="Enter Email..">
    </div>

    <div class="tx-box">
      <label>Phone Number :</label>
      <input type="text" name="number"  value="" placeholder="Enter Phone Number..">
    </div>

    <div class="tx-box">
   
      <label>Message :</label>
      <input type="text" name="message"  value="" placeholder="Write Something..">
  
    </div>
    <input type="submit" name="save" class="btn">
  </div>
  </form>

</body>
</html>

<?php include 'footer.php' ?>