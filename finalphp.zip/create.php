<?php include 'db.php' ;
$Username= $_POST['Username'];
$Email= $_POST['Email'];
$Password= $_POST['Password'];
$RepeatPassword= $_POST['RepeatPassword'];

$sql="insert into register (Username, Email, Password,RepeatPassword)
values('$Username', '$Email', '$Password','$RepeatPassword')";

if($conn->query($sql) === TRUE) {
    echo "New record added";
    
    echo "<a href='home.php' class='top'>Home </a>";
}
else
{
    echo "ERROR: " .$sql. "<br>" . $conn->error;
}
$conn->close();

?>