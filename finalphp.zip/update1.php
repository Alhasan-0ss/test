

<?php
include 'database.php'; 
$sql = "select * from employee";
$result = $conn->query($sql); ?>
<html>
<head>
<style>

    
    
    
    body{
    font-weight: 400;
    color: white;
    letter-spacing: 1px;
        background-image: url("image4.jpg");
        background-size:cover;
        background-color: #cccccc;
}
    tr

{

height:50px;
}
a.top{
    margin-right:50px;
    font size:30px;
    color:#000;
    align:center;
}
.top{
text-align:center;
}
    a.top:hover{
        color:#12725C;
    }

table

{

border-style:solid;
color: black;
border-width:2px;

border-color:black;;
margin: 0 auto;
}
.head{
    text-align: center;
    font-size: 50px;
    text-transform: uppercase;
    color:black;
}
    .link{
        color: black;
        
    }
   
</style>
<title>Update Data</title>
</head>
<body>
<h1 class="head">CHECK RESERVATION</h1>
<div class ="top">
<a href="index1.php" class="top">New Reservation </a>
    <a href="menu.php" class="top">Menu </a>
<a href="retrive1.php" class="top">Booked Resservation</a>

<hr>
</div>
<table border="1" cellpadding="10">
<tr>

<th>Id</th>

<th>Your Name</th>

<th>Your Email</th>

<th>Date</th>
<th>Time</th>
<th>Member</th>
<th>Update</th>
<th>Cancel</th>
</tr>
<?php
if($result ->num_rows > 0) {
    while($row = $result ->fetch_assoc())

  {
      ?>

  <tr>
  <td><?php echo $row["id"]; ?></td>
  <td><?php echo $row["first_name"]; ?></td>
  <td><?php echo $row["last_name"]; ?></td>
  <td><?php echo $row["city_name"]; ?></td>
  <td><?php echo $row["email"]; ?></td>
  <td><?php echo $row["member"]; ?></td>
  <div class="link">
<td><a href="updatesingle.php?id=<?php echo $row['id']; ?>">Update</a></td>
<td><a href="delete.php?id=<?php echo $row['id']; ?>">Cancel</a></td>
</div>
</tr>
<?php
  }
}
else
{
    echo "no results";
}
 
$conn->close(); ?>



</table>
</body>
</html>

