<?php
include_once 'database.php';
if(isset($_POST['save'])){	 
	$id=isset($_POST['id']);
	 $first_name = $_POST['first_name'];
	 $last_name = $_POST['last_name'];
	 $city_name = $_POST['city_name'];
	 $email = $_POST['email'];
	 $member = isset($_POST['member']);
	 $sql = "INSERT INTO employee (first_name,last_name,city_name,email,member)
	 VALUES ('$first_name','$last_name','$city_name','$email','$member')";
	 if (mysqli_query($conn, $sql)) {
		header("location: index1.php");
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	
	}

	 mysqli_close($conn);
}
?>