<?php
include 'db.php';
$a = $_GET['Id'];
$result = mysqli_query($conn,"SELECT * FROM register WHERE Id= '$a'");
$row= mysqli_fetch_array($result);
?>
<html>
<head>
<title>Update signup Data</title>
</head>
<body>
<form method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
Username: <br>
<input type="text" name="Username"  value="<?php echo $row['Username']; ?>">
<br>
Email :<br>
<input type="text" name="Email" value="<?php echo $row['Email']; ?>">
<br>
Passowrd:<br>
<input type="Password" name="Password" value="<?php echo $row['Password']; ?>">
<br>
RepeatPassowrd:<br>
<input type="RepeatPassword" name="RepeatPassword" value="<?php echo $row['RepeatPassword']; ?>">



<input type="submit" name="submit" value="Submit">
</form>
<?php 
if($_POST['submit']){
    
    $Username = $_POST['Username'];
    $query = mysqli_query($conn,"UPDATE register set Username='$Username' where Id='$a'");
    if($query){
        echo "Record Modified Successfully <br>";
        echo "<a href='update.php'> Check your updated List </a>";
        // if you want to redirect to update page after updating
        //header("location: update.php");
    }
    else { echo "Record Not modified";}
    }
$conn->close();
?>
</body>
</html>