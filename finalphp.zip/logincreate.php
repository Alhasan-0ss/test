<?php include 'logindb.php';
$Username= $_POST['Username'];
$Password= $_POST['Password'];


$sql="insert into login (Username,Password)
values('$Username','$Password')";

if($conn->query($sql) === TRUE) {
    echo "New record added";
    
    echo "<a href='home.php' class='top'>Home </a>";
}
else
{
    echo "ERROR: " .$sql. "<br>" . $conn->error;
}
$conn->close();

?>





