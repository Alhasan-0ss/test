<?php
require 'db.php'; 
$sql = "select * from register";
$result = $conn->query($sql);?>
<html>
<head>
    <style>
        a.top {
            margin-right:20px;
            font-size:20px;
            color:red;
        }
        </style>
<title> Update Data</title>
</head>
<body>
    <a href="form.php" class="top">Create Data </a>
    <a href="update.php" class="top">Update/Remove Data </a>
    <a href="read.php" class="top">Retrieve Data </a>
<hr>
<table border="1" cellpadding="5">
<tr>
<th>ID</th><th>Username</th><th>Email</th>
<th>Password</th> <th>Edit</th>
<th>Remove</th>
</tr>
<?php 
if($result ->num_rows > 0) {
    while($row = $result ->fetch_assoc()){
?>
<tr>
<td><?php echo $row["Id"]; ?></td>
<td><?php echo $row["Username"]; ?></td>
<td><?php echo $row["Email"]; ?></td>
<td><?php echo $row["Password"]; ?></td>

<td><a href="updatesingle.php?id=<?php echo $row['Id']; ?>">Update</a></td>
<td><a href="delete.php?id=<?php echo $row['Id']; ?>">Remove</a></td>
</tr>

<?php 
}
}
else
{
    echo "no results";
}
$conn->close();
?>
</table>
</body>
</html>