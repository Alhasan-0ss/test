
<?php
$servername = "localhost";
$username = "mama1";
$password = "password";
$dbname = "mama1";
//Creating connection
$conn = new mysqli ($servername, $username, $password, $dbname);
// check connection
if($conn->connect_error){
    die("Connection failed; " . $conn->connect_error);
}
?> 


