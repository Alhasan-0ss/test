<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-32">

<body>
<hr style="border-color:white">
<div class="container">
<h1 align="center">MAMA Restaurant</h1>

<h3></h3>
    <hr>
        <div class="text-center center-block">
            <p class="txt-railway"> @2020 copyright: MAMARestaurant.fi </p>
            <br />
                <a href="https://www.facebook.com/bootsnipp"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
	            <a href="https://twitter.com/bootsnipp"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
	            <a href="https://plus.google.com/+Bootsnipp-page"><i id="social-gp" class="fa fa-google-plus-square fa-3x social"></i></a>
	            <a href="mailto:bootsnipp@gmail.com"><i id="social-em" class="fa fa-envelope-square fa-3x social"></i></a>
</div>
    <hr>
<div>

</div> </div><br>
  <a class="w-toplink active" href="#" title="Back to top">
    ::before
    </a>
<!-- Social Footer, Single Coloured -->
<!-- Include Font Awesome Stylesheet in Header -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<!-- // -->
</body>
