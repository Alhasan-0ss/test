
<?php
include 'database.php';
$a = $_GET['id'];
$result = mysqli_query($conn,"SELECT * FROM employee WHERE id= '$a'");
$row= mysqli_fetch_array($result);
?>
<html>
<head>
<meta  charset="UTF-8">
     <title>MAMA RESTAURANT</title>
     <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">  
<link rel="stylesheet" href="reserv.css">
<style>
.btn{
    background-color: black;
    color:#fff;
    padding: 10px 20px;
    border: none !important;
    font-size: 18px;
    border-radius: 100px;
    align-content: center;
     
}
.btn:hover{
    color: red;
}
</style>
</head>
<body>
<h1 class="head">UPDATE RESERVATION</h1>

       <div class="container">
        <div class="container-time">
           <h2 class ="heading">Time Open</h2>
           <h3 class = "heading-day">Monday-Friday</h3>
           <p>9am - 11pm (Breakfast)</p>
            <p>11am - 9pm (Lunch/Dinner)</p>
            
            <h3 class="heading-day">Saturday and Sunday </h3>
            <p>9am - 1am (Breakfast)</p>
            <p>11am - 10pm (Lunch/Dinner)</p>
            
            <hr>
            <h4 class="heading-phone">Call Us:(+358)455-547-75</h4>
           </div>
           <div class="container-form">
          
                <h2 class ="heading-two">Update Reservation</h2>
<form method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<div class="form-field">
		<p>Your Name:</p>
<input type="text" name="fname" class="arpit" value="<?php echo $row['first_name']; ?>">
<br></div>

<div class="form-field">
		<p>Your email:</p>
<input type="text" name="lname" class="arpit" value="<?php echo $row['last_name']; ?>">
<br></div>
<div class="form-field">
		<p>Date:</p>
<input type="date" name="city" class="arpit" value="<?php echo $row['city_name']; ?>">
<br></div>
<div class="form-field">
		<p>Time:</p>
<input type="time" name="groupid" class="arpit" value="<?php echo $row['email']; ?>">
<br></div>
<div class="form-field">
		<p>Number Of Members</p>
<input type="text" name="member" class="arpit" value="<?php echo $row['member']; ?>">
<br></div>
<input type="submit" name="submit" class="btn" value="Update" >
</form>
<?php 
if (isset($_POST['submit'])){
    

    $fname= $_POST['fname']; 
    $lname= $_POST['lname'];
    $city= $_POST['city'];
    $time= $_POST['groupid'];
    $mem= $_POST['member'];
    $id = $_GET['id'];
  
    $query = mysqli_query($conn,"UPDATE employee SET first_name='$fname',last_name='$lname',city_name='$city',email='$time',member='$mem' where id='$a'");
    
    if($query)
    {
        echo "Record Modified Successfully <br>";
    echo "<a href='update1.php'> Check your updated List </a>";
      //  if you want to redirect to update page after updating
        header("location: update1.php");
  
    }
    

    else {   
    $a;
    echo "Record Not modified";}
    
}
    
$conn->close();
?>




</body>
</html>