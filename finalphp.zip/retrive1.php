

<?php
include 'database.php'; 
$sql = "select * from employee";
$result = $conn->query($sql); ?>
<html>
<head>
<style>
tr

{

height:50px;
}
a.top{
    margin-right:50px;
    font size:40px;
    color:black;
    align:center;
}
.top{
text-align:center;
}


table

{

border-style:solid;

border-width:2px;

border-color:black;
    text-decoration-color: black;
    color: black;
margin: 0 auto;
}
. div h1{
  test-align:center;
}
.head{
    text-align: center;
    font-size: 50px;
    text-transform: uppercase;
    color:black;
}
    body{
    font-weight: 400;
    color: white;
    letter-spacing: 1px;
        background-image: url("image4.jpg");
        background-size:cover;
        background-color: #cccccc;
}
    .tr{
        color: black;
    }

</style>
<title>Update Data</title>
</head>
<body>

<h1 class="head">BOOKED RESERVATION</h1>
<div class ="top">
<a href="index1.php" class="top"> NEW RESERVATION </a>


<hr>
</div>
<table border="1" cellpadding="10">
<tr>

<th>Id</th>

<th>Your Name</th>

<th>Your Email</th>

<th>Date</th>
<th>Time</th>
<th>Member</th>

</tr>
<?php
if($result ->num_rows > 0) {
    while($row = $result ->fetch_assoc())

  {
      ?>

  <tr>
  <td><?php echo $row["id"]; ?></td>
  <td><?php echo $row["first_name"]; ?></td>
  <td><?php echo $row["last_name"]; ?></td>
  <td><?php echo $row["city_name"]; ?></td>
  <td><?php echo $row["email"]; ?></td>
  <td><?php echo $row["member"]; ?></td>
  

</tr>
<?php
  }
}
else
{
    echo "no results";
}
 
$conn->close(); ?>



</table>
</body>
</html>



