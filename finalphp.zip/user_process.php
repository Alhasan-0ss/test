<?php include 'dbconnect.php' ;
$fullname= $_POST['fullname'];
$email= $_POST['email'];
$number= $_POST['number'];
$message= $_POST['message'];

$sql="insert into contact (fullname, email, number,message)
values('$fullname', '$email', '$number','$message')";

if($conn->query($sql) === TRUE) {
    echo "New record added";
    
    echo "<a href='home.php' class='top'>Home </a>";
}
else
{
    echo "ERROR: " .$sql. "<br>" . $conn->error;
}
$conn->close();

?>
